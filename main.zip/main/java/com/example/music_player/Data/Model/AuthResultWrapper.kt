package com.example.music_player.Data.Model

import com.google.firebase.auth.FirebaseUser

sealed class AuthResultWrapper {
    data class Success(val user: FirebaseUser?) : AuthResultWrapper()
    data class Failure(val errorMessage: String) : AuthResultWrapper()
}