package com.example.music_player.Data.Model

data class user (
    val email:String,
    val name:String,
    val likedSongs:List<String>? = null,
    val createdPlaylist:List<String>? = null,
    val playbackHistory:List<String>? = null
)
