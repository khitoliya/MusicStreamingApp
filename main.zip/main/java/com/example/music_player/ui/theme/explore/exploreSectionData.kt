package com.example.music_player.ui.theme.explore

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.ui.graphics.Color
import com.example.music_player.GridItem

val sampleItems = listOf(
    GridItem(
        subheading = "Music",
        icon = Icons.Default.MusicNote,
        gradientColors = listOf(Color(0xFF6A11CB), Color(0xFF2575FC)),
    ),
    GridItem(
        subheading = "Videos",
        icon = Icons.Default.PlayArrow,
        gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
    ),
    GridItem(
        subheading = "Music",
        icon = Icons.Default.MusicNote,
        gradientColors = listOf(Color(0xFF6A11CB), Color(0xFF2575FC))
    ),
    GridItem(
        subheading = "Videos",
        icon = Icons.Default.PlayArrow,
        gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
    ),
    GridItem(
        subheading = "Music",
        icon = Icons.Default.MusicNote,
        gradientColors = listOf(Color(0xFF6A11CB), Color(0xFF2575FC))
    ),
    GridItem(
        subheading = "Videos",
        icon = Icons.Default.PlayArrow,
        gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
    ),
    GridItem(
        subheading = "Music",
        icon = Icons.Default.MusicNote,
        gradientColors = listOf(Color(0xFF6A11CB), Color(0xFF2575FC))
    ),
    GridItem(
        subheading = "Videos",
        icon = Icons.Default.PlayArrow,
        gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
    ),
    // Add more items...
)

val sections = listOf(
    listOf("Moods & Activities", sampleItems),
    listOf("Music By Genre", sampleItems),
    listOf("Listen Your Way", sampleItems),

)