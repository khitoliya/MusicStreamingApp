package com.example.music_player


import android.os.Build
import androidx.annotation.OptIn
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.music_player.navigation.Screens
import com.example.music_player.ui.theme.Player.MusicViewModel
import com.example.music_player.ui.theme.explore.GridItemDetailScreen
import com.example.music_player.ui.theme.explore.exploreSection
import com.example.music_player.ui.theme.home.homeScreen
import com.example.music_player.ui.theme.library.LibrarySection
import com.example.music_player.ui.theme.login.LoginViewModel
import com.example.music_player.ui.theme.profile.ProfileSection


@OptIn(UnstableApi::class)
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun MainAppScaffold(mainNavController: NavController, loginViewModel: LoginViewModel,musicViewModel: MusicViewModel) {
    val bottomNavController = rememberNavController() // 🔥 Separate NavController for bottom navigation


    Scaffold(
        bottomBar = { BottomBar(bottomNavController = bottomNavController,musicViewModel,mainNavController=mainNavController) },
        containerColor = Color.Black
    ) { innerPadding ->
        Box(modifier = Modifier.padding(top = 0.dp, bottom = innerPadding.calculateBottomPadding()).background(Color.Black)) {
            NavHost(
                navController = bottomNavController, // 🔥 Controls only the bottom tabs
                startDestination = Screens.homeScreen.route
            ) {
                composable("home",arguments = emptyList()) { homeScreen(userName = "Rohit",bottomNavController=bottomNavController, loginViewModel = loginViewModel, mainNavController = mainNavController, musicViewModel = musicViewModel) }
                composable("explore",arguments = emptyList()) { exploreSection(bottomNavController) }
                composable("library",arguments = emptyList()) { LibrarySection(bottomNavController) }
                composable("profile",arguments = emptyList()) { ProfileSection(bottomNavController) }
                composable ( "gridItemDetail/{itemHeading}" ){backStackEntry ->
                    GridItemDetailScreen(
                        bottomNavController,
                        heading = backStackEntry.arguments?.getString("itemHeading").toString()) }

            }
        }
    }

}
