package com.example.music_player.ui.theme.otpVerification

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.music_player.EmailTextField
import com.example.music_player.greenButton
import com.example.music_player.navigation.Screens

@Composable
fun forgotpasswordScreen(navController: NavController,viewModel: ForgotPasswordViewModel=hiltViewModel()) {
    var email by remember { mutableStateOf("") }
    val uiState by viewModel.uiState.collectAsState()
    var showSuccessDialog by remember { mutableStateOf(false) }

    // Handle success state to show dialog
    LaunchedEffect(uiState) {
        if (uiState is ForgotPasswordUiState.Success) {
            showSuccessDialog = true
        }
    }
    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = { /* Dialog can't be dismissed without clicking OK */ },
            title = {
                Text(
                    text = "Email Sent",
                    color = Color.White
                )
            },
            text = {
                Text(
                    text = "Password reset link has been sent to your email address.",
                    color = Color.White
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        navController.popBackStack() // Navigate back to login
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Green,
                        contentColor = Color.White
                    )
                ) {
                    Text("OK")
                }
            },
            containerColor = Color(0xFF1E1E1E), // Dark background
            titleContentColor = Color.White,
            textContentColor = Color.White
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {

        // Back Button & Title
        Spacer(modifier = Modifier.height(30.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { navController.navigateUp() }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
            Text(
                text = "Forgot Password",
                fontSize = 20.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(30.dp))

        EmailTextField(email,{email=it})


        if (uiState is ForgotPasswordUiState.Error) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = (uiState as ForgotPasswordUiState.Error).message,
                color = Color.Red,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }


        Spacer(modifier = Modifier.height(20.dp))
        //verify button
        greenButton(
            "Reset Password",
            {if (email.isNotBlank()) {
                viewModel.sendPasswordResetEmail(email)
            } else {
                viewModel.setErrorState("Please enter your email")
            }
            }
        )



    }
}

