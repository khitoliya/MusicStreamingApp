package com.example.music_player.ui.theme.otpVerification

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.music_player.Data.Model.AuthResultWrapper
import com.example.music_player.Data.Repository.AuthRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

@HiltViewModel
class ForgotPasswordViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {
    // Rest of your ViewModel code remains the same...
// UI State
    private val _uiState = MutableStateFlow<ForgotPasswordUiState>(ForgotPasswordUiState.Idle)
    val uiState: StateFlow<ForgotPasswordUiState> = _uiState.asStateFlow()
fun setErrorState(error: String){
    _uiState.value = ForgotPasswordUiState.Error(error)
}
    // ForgotPasswordViewModel.kt
    fun sendPasswordResetEmail(email: String) {
        viewModelScope.launch {
            _uiState.value = ForgotPasswordUiState.Loading

            // Basic email format validation
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                _uiState.value = ForgotPasswordUiState.Error("Please enter a valid email address")
                return@launch
            }

            when (val result = authRepository.sendPasswordResetEmail(email)) {
                is AuthResultWrapper.Success -> {
                    _uiState.value = ForgotPasswordUiState.Success(
                        message = "Password reset link sent to $email"
                    )
                }
                is AuthResultWrapper.Failure -> {
                    _uiState.value = ForgotPasswordUiState.Error(result.errorMessage)
                }
            }
        }
    }
}

// UI States
sealed interface ForgotPasswordUiState {
    object Idle : ForgotPasswordUiState
    object Loading : ForgotPasswordUiState
    data class Success(val message: String) : ForgotPasswordUiState
    data class Error(val message: String) : ForgotPasswordUiState
}
