package com.example.music_player.ui.theme.Player


import android.app.Application
import android.app.Service.STOP_FOREGROUND_REMOVE
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.OptIn
import androidx.annotation.RequiresApi
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import com.example.music_player.Data.Model.song
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@UnstableApi
@HiltViewModel
class MusicViewModel @Inject constructor(application: Application) : AndroidViewModel(application) {

    private val appContext: Context by lazy { application.applicationContext }
    private var musicService: MediaPlayerService? = null

    private val _isPlaying = MutableStateFlow<Boolean>(false)
    val isPlaying: StateFlow<Boolean>  = _isPlaying

    private val _currentSong = MutableStateFlow<song?>(null)
    val currentSong: StateFlow<song?>  = _currentSong

    private val _maxDuration = MutableStateFlow<Float>(0f)
    val maxDuration: StateFlow<Float>  = _maxDuration

    private val _currDuration = MutableStateFlow<Float>(0f)
    val currDuration: StateFlow<Float> = _currDuration
    private val _isBound = MutableStateFlow<Boolean>(false)
    val isBound: StateFlow<Boolean> = _isBound

    private val _isPlayerReady = MutableStateFlow(false) // New StateFlow for readiness
    val isPlayerReady: StateFlow<Boolean> = _isPlayerReady // Expose to UI

    private val _MiniPlayerOpen = MutableStateFlow<Boolean>(false)
    val MiniPlayerOpen: StateFlow<Boolean> = _MiniPlayerOpen

    private val _songList = MutableStateFlow<List<song>>(emptyList())
    val songList: StateFlow<List<song>> = _songList

    enum class RepeatMode {
        OFF,
        REPEAT_ALL,
        REPEAT_ONE
    }

    private val _repeatMode = MutableStateFlow(RepeatMode.REPEAT_ALL)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode


    fun toggleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.REPEAT_ALL
            RepeatMode.REPEAT_ALL -> RepeatMode.REPEAT_ONE
            RepeatMode.REPEAT_ONE -> RepeatMode.OFF
        }
        musicService?.toggleRepeatMode()
    }

    private val _isShuffleOn = MutableStateFlow(false)
    val isShuffleOn: StateFlow<Boolean> get() = _isShuffleOn

    fun toggleShuffle() {
        _isShuffleOn.value = !_isShuffleOn.value
        musicService?.toggleShuffle()
        // Add your shuffle logic here
    }

    private val _isLiked = MutableStateFlow(false)
    val isLiked: StateFlow<Boolean> get() = _isLiked

    fun toggleLike() {
        _isLiked.value = !_isLiked.value
        // Add your like/unlike logic here
    }

    private val serviceConnection = object : ServiceConnection {
        @OptIn(UnstableApi::class)
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? MediaPlayerService.MusicBinder
            musicService = binder?.getService()
            viewModelScope.launch {
                binder?.isPlaying()?.collectLatest {
                    _isPlaying.value = it
                    Log.d("MusicViewModel", "isPlaying updated: $it")
                }
            }
            viewModelScope.launch {
                binder?.maxDuration()?.collectLatest {
                    _maxDuration.value = it
                    Log.d("MusicViewModel", "maxDuration updated: $it")
                }
            }
            viewModelScope.launch {
                binder?.currentDuration()?.collectLatest {
                    _currDuration.value = it
                    Log.d("MusicViewModel", "currDuration updated: $it")
                }
            }
            viewModelScope.launch {
                binder?.getCurrSong()?.collectLatest {
                    _currentSong.value = it
                    Log.d("MusicViewModel", "currentSong updated: ${it?.title}")
                }
            }
            viewModelScope.launch {
                binder?.isPlayerReady()?.collectLatest { _isPlayerReady.value = it } // Collect readiness
            }
            _isBound.value = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            _isBound.value=false
            musicService = null
        }
    }

    fun setMiniPlayerOpen(value: Boolean){
        _MiniPlayerOpen.value=value
    }


    @OptIn(UnstableApi::class)
    @RequiresApi(Build.VERSION_CODES.O)
    fun startMusicService(songs: List<song>) {
        _currentSong.value=songs[0]
        val intent = Intent(appContext, MediaPlayerService::class.java).apply {
            putParcelableArrayListExtra("MUSIC_LIST", ArrayList(songs)) // Send new list
        }

        try {
            appContext.startForegroundService(intent)
            appContext.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        } catch (e: Exception) {
            Log.e("MusicViewModel", "Error starting service: ${e.message}")
        }
    }

    fun stopMusicService() {
        try {
            musicService?.let {
                it.stopForeground(STOP_FOREGROUND_REMOVE) // Remove notification
                it.stopSelf() // Stop the service
                appContext.unbindService(serviceConnection)
            }
            _isPlaying.value = false
            _isPlayerReady.value = false
            _isBound.value = false
            musicService = null
        } catch (e: Exception) {
            Log.e("MusicViewModel", "Error stopping service: ${e.message}")
        }
    }

    @OptIn(UnstableApi::class)
    fun setMusicList(songList: List<song>) {
        _songList.value = songList // Update song list
        musicService?.binder?.setMusicList(songList)

    }

    @OptIn(UnstableApi::class)
    fun playPause() {
        musicService?.playPause()
    }

    @OptIn(UnstableApi::class)
    fun seekTo(seekPosition: Long) {
        musicService?.seekTo(seekPosition)
    }

    @OptIn(UnstableApi::class)
    fun next() {
        musicService?.next()
    }

    @OptIn(UnstableApi::class)
    fun prev() {
        musicService?.prev()
    }

    @OptIn(UnstableApi::class)
    @RequiresApi(Build.VERSION_CODES.O)
    fun playSong(song: song) {
        _currentSong.value = song
        musicService?.let {
            // Update musicList to include the new song as the current one
            val currentList = _songList.value.toMutableList()
            if (!currentList.contains(song)) {
                currentList.add(0, song) // Add new song at the start
                _songList.value = currentList
                it.binder.setMusicList(currentList)
            }
            it.playWithCaching(song) // Use the service's playWithCaching method
        } ?: run {
            Log.d("MusicList","Service Not declared")
            // If service isn’t running, start it with the current song list including the new song
            val updatedList = mutableListOf(song)  //.apply { addAll(_songList.value) }
            _songList.value = updatedList
            startMusicService(updatedList)
        }
    }

    @OptIn(UnstableApi::class)
    fun addToQueue(song: song) {
        if(_songList.value.contains(song)){
            Log.d("MusicList","Already in queue")
            return
        }
        val currentList = _songList.value.toMutableList()
        currentList.add(song)
        _songList.value = currentList
        musicService?.binder?.setMusicList(currentList)
    }
    override fun onCleared() {
        super.onCleared()
        stopMusicService() // Stop service when ViewModel is cleared
    }
}




