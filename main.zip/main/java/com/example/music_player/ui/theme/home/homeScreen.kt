package com.example.music_player.ui.theme.home

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavController
import com.example.music_player.Data.Model.song
import com.example.music_player.GridItem
import com.example.music_player.GridWithHeader
import com.example.music_player.ui.theme.Player.MusicViewModel
import com.example.music_player.ui.theme.Player.PlayerScreen
import com.example.music_player.ui.theme.login.LoginViewModel

@RequiresApi(Build.VERSION_CODES.O)
@androidx.annotation.OptIn(UnstableApi::class)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun homeScreen(userName: String, bottomNavController: NavController, loginViewModel: LoginViewModel,mainNavController: NavController,musicViewModel: MusicViewModel) {
    val context = LocalContext.current
    Scaffold(
        topBar = { HomeTopbar(userName) },
        containerColor = Color.Black
    ) { innerPadding ->
        // Main content area
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Your home screen content goes here
            Text(
                text = "Home Content",
                color = Color.White,

            )

            Button({loginViewModel.logout()}) {Text("LogOut") }
            Button(onClick = {
                val songList = listOf(
                    song(title = "Song 2", artist = "Artist 2", youtubeId = "1BEAb30UlmoOEsBvz9W9uYltqn053wWCe")
                )
                musicViewModel.setMusicList(songList)
                musicViewModel.playSong(songList[0]) // Start playing immediately
                mainNavController.navigate("player")

            }) {
                Text(text = "Play Bali battel")
            }

            Button(onClick = {
                val songList = listOf(
                    song(title = "Tell Me", artist = "Karan Aujla", youtubeId = "1WhYhqFDkSa4QY-6G2XC49spKm9rIh2F3", thumbnailUrl = "https://i.scdn.co/image/ab67616d00001e02c3e1ee4bc3d39a1b130925bb"),

                )
                musicViewModel.setMusicList(songList)
                musicViewModel.playSong(songList[0]) // Start playing immediately
                mainNavController.navigate("player")

            }) {
                Text(text = "Play TellMe")
            }

            Button(onClick = {
                val song = song(title = "Song 3", artist = "Artist 3", youtubeId = "1WhYhqFDkSa4QY-6G2XC49spKm9rIh2F3")
                musicViewModel.addToQueue(song)
            }) {
                Text("Add Tell me to Queue")
            }


            val sampleItems = listOf(
                GridItem(
                    subheading = "Music",
                    icon = Icons.Default.MusicNote,
                    gradientColors = listOf(Color(0xFF6A11CB), Color(0xFF2575FC))
                ),
                GridItem(
                    subheading = "Videos",
                    icon = Icons.Default.PlayArrow,
                    gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
                ),
                GridItem(
                    subheading = "Videos",
                    icon = Icons.Default.PlayArrow,
                    gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
                ),
                GridItem(
                    subheading = "Videos",
                    icon = Icons.Default.PlayArrow,
                    gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
                ),
                GridItem(
                    subheading = "Videos",
                    icon = Icons.Default.PlayArrow,
                    gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
                ),
                GridItem(
                    subheading = "Videos",
                    icon = Icons.Default.PlayArrow,
                    gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
                ),
                GridItem(
                    subheading = "Videos",
                    icon = Icons.Default.PlayArrow,
                    gradientColors = listOf(Color(0xFF11998E), Color(0xFF38EF7D))
                ),
                // Add more items...
            )

            GridWithHeader(
                heading = "Categories",
                items = sampleItems,
                onItemClick = { index ->
                    // Handle item click
                    println("Clicked item at index $index")
                },
                onSeeMoreClick = {
                    // Handle see more click
                    println("See more clicked")
                },
                modifier = Modifier.padding(16.dp)
            )

        }
    }
}



// Helper function to get time-based greeting



