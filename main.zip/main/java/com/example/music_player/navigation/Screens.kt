package com.example.music_player.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Person
import androidx.compose.ui.graphics.vector.ImageVector

sealed  class Screens (
    val route: String,
    val filledIcon: ImageVector? =null,
    val outlinedIcon: ImageVector? =null){
    object loginScreen:Screens("loginScreen")
    object loginWhithEmailScreen:Screens("loginWhithEmailScreen")
    object createAccountScreen:Screens("CreateAccountScreen")
    object homeScreen:Screens("home", Icons.Filled.Home,Icons.Outlined.Home)
    object forgotPasswordScreen:Screens("forgotPasswordScreen")
    object explore: Screens("explore",Icons.Filled.Explore,Icons.Outlined.Explore)
    object library: Screens("library",Icons.Filled.LibraryMusic,Icons.Outlined.LibraryMusic)
    object Profile: Screens("profile",Icons.Filled.Person,Icons.Outlined.Person)
    object mainScreen : Screens("MainScreen")
}
