package com.example.music_player.ui.theme.Player

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.annotation.RequiresApi
import androidx.compose.animation.animateColor
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDp
import androidx.compose.animation.core.updateTransition
import androidx.compose.foundation.Image

import androidx.compose.runtime.remember
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape

import androidx.compose.material3.Slider

import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Downloading
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HeartBroken
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.music_player.R
import com.example.music_player.ui.theme.Player.MusicViewModel.RepeatMode
import java.util.concurrent.TimeUnit

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun PlayerScreen(viewModel: MusicViewModel, mainNavController: NavController) {
    // Start playing the song as soon as the screen is opened
    val songList by viewModel.songList.collectAsState()
    val isBound by viewModel.isBound.collectAsState()

    BackHandler {
        viewModel.setMiniPlayerOpen(true)
        mainNavController.navigateUp()
    }

    LaunchedEffect(songList) {
        if (songList.isNotEmpty() && !isBound) {
            viewModel.startMusicService(songList)
        }
    }

    val isPlaying by viewModel.isPlaying.collectAsState()
    val currSong by viewModel.currentSong.collectAsState()
    val currDuration by viewModel.currDuration.collectAsState()
    val maxDuration by viewModel.maxDuration.collectAsState()
    val isPlayerReady by viewModel.isPlayerReady.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF121212)), verticalArrangement = Arrangement.Center

    ) {
                Spacer(modifier = Modifier.height(32.dp))
                // Top Bar with back button and menu
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            viewModel.setMiniPlayerOpen(true)
                            mainNavController.navigateUp()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    LikeButton(viewModel = viewModel)
                }

                Spacer(modifier = Modifier.height(32.dp))
                // Main Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    // Album Art/Thumbnail

                    AsyncImage(
                        model = currSong?.thumbnailUrl ?: "",
                        contentDescription = "Album Art",
                        modifier = Modifier
                            .size(350.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .shadow(elevation = 12.dp, shape = RoundedCornerShape(28.dp)),
                        contentScale = ContentScale.Crop,
                        placeholder = painterResource(id = R.drawable.placeholder), // Add a placeholder in your drawables
                        error = painterResource(id = R.drawable.placeholder) // Add an error placeholder
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Song Title
                    Text(
                        text = currSong?.title ?: "Unknown Song",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Artist Name
                    Text(
                        text = currSong?.artist ?: "Unknown Artist",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Divider
                    Divider(
                        color = Color.White.copy(alpha = 0.2f),
                        thickness = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress Bar with time indicators
                    Column(modifier = Modifier.fillMaxWidth()) {
                        SpotifyStyleSlider(
                            value = if (maxDuration > 0f) currDuration / maxDuration else 0f,
                            onValueChange = { newValue ->
                                val seekPosition = (newValue * maxDuration).toLong()
                                viewModel.seekTo(seekPosition)
                            },
                            modifier = Modifier
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Current time
                            Text(
                                text = formatDuration(currDuration),
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 15.sp
                            )

                            // Total time
                            Text(
                                text = formatDuration(maxDuration),
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 15.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    // Player Controls
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ShuffleButton(viewModel = viewModel)
                        // Previous Button
                        IconButton(
                            onClick = { viewModel.prev() },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipPrevious,
                                contentDescription = "Previous",
                                tint = Color.White,
                                modifier = Modifier.size(44.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Play/Pause Button
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color.Green),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(
                                onClick = { if (isPlayerReady) viewModel.playPause() },
                                modifier = Modifier.size(64.dp)
                            ) {
                                if (!isPlayerReady) {
                                    CircularProgressIndicator(color = Color.Black)
                                } else {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = Color.Black,
                                        modifier = Modifier.size(44.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Next Button
                        IconButton(
                            onClick = { viewModel.next() },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = "Next",
                                tint = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                        RepeatButton(viewModel)
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    // Additional controls row (you can add your buttons here)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {

                        IconButton(onClick = { /* handle share */ }) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "share song",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        IconButton(onClick = { /* download..save offline */ }) {
                            Icon(
                                imageVector = Icons.Default.Downloading,
                                contentDescription = "open Queue",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        IconButton(onClick = { /* open Queue */ }) {
                            Icon(
                                imageVector = Icons.Default.PlaylistPlay,
                                contentDescription = "open Queue",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        IconButton(onClick = { /* open menu */ }) {
                            Icon(
                                imageVector = Icons.Default.MoreHoriz,
                                contentDescription = "open Queue",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                    }
                }
    }
}

// Helper function to format duration in milliseconds to MM:SS format
private fun formatDuration(duration: Float): String {
    val minutes = TimeUnit.MILLISECONDS.toMinutes(duration.toLong())
    val seconds = TimeUnit.MILLISECONDS.toSeconds(duration.toLong()) -
            TimeUnit.MINUTES.toSeconds(minutes)
    return String.format("%02d:%02d", minutes, seconds)
}

@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotifyStyleSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }

    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp),
        interactionSource = interactionSource,
        colors = SliderDefaults.colors(
            thumbColor = Color.Transparent,
            activeTrackColor = Color.Transparent,
            inactiveTrackColor = Color.Transparent
        ),
        thumb = {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .shadow(3.dp, CircleShape)
                    .background(Color.Green, CircleShape)
                    .border(1.dp, Color.Black.copy(alpha = 0.2f), CircleShape)
            )
        },
        track = { sliderPositions ->
            Box(modifier = Modifier.fillMaxWidth()) {
                // Background track (inactive portion)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color.Gray.copy(alpha = 0.3f))
                        .align(Alignment.CenterStart)
                )

                // Progress track (active portion)
                Box(
                    modifier = Modifier
                        .fillMaxWidth(sliderPositions.value)
                        .height(7.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color.Green)
                        .align(Alignment.CenterStart)
                )
            }
        }
    )
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun RepeatButton(viewModel: MusicViewModel) {
    val repeatMode by viewModel.repeatMode.collectAsState()

    Box(
        modifier = Modifier.size(48.dp),
        contentAlignment = Alignment.Center
    ) {
        // Base repeat icon
        Icon(
            imageVector = Icons.Default.Repeat,
            contentDescription = "Repeat",
            tint = when (repeatMode) {
                RepeatMode.OFF -> Color.White
                RepeatMode.REPEAT_ALL -> Color.Green
                RepeatMode.REPEAT_ONE -> Color.Green
            },
            modifier = Modifier.size(24.dp)
        )

        // "1" badge for repeat one mode
        if (repeatMode == RepeatMode.REPEAT_ONE) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .offset(x = 6.dp, y = (-6).dp)
                    .background(Color.Green, CircleShape)
                    .border(1.dp, Color(0xFF121212), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "1",
                    color = Color.Black,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Invisible clickable surface
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable { viewModel.toggleRepeatMode() }
                .alpha(0f) // Make invisible but clickable
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
fun ShuffleButton(viewModel: MusicViewModel) {
    val isShuffleOn by viewModel.isShuffleOn.collectAsState()

    IconButton(
        onClick = { viewModel.toggleShuffle() },
        modifier = Modifier.size(48.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Shuffle,
            contentDescription = "Shuffle",
            tint = if (isShuffleOn) Color.Green else Color.White,
            modifier = Modifier
                .size(28.dp)
                .graphicsLayer {
                    rotationZ = if (isShuffleOn) 180f else 0f
                }
                .animateContentSize()
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
fun LikeButton(viewModel: MusicViewModel) {
    val isLiked by viewModel.isLiked.collectAsState()
    val transition = updateTransition(targetState = isLiked, label = "likeTransition")

    // Animate color change
    val tint by transition.animateColor(label = "tint") { liked ->
        if (liked) Color(0xFFff4d6d) else Color.White
    }

    // Animate size change
    val size by transition.animateDp(label = "size") { liked ->
        if (liked) 32.dp else 28.dp
    }

    IconButton(
        onClick = { viewModel.toggleLike() },
        modifier = Modifier.size(48.dp)
    ) {
        Icon(
            imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.Favorite,
            contentDescription = if (isLiked) "Unlike" else "Like",
            tint = tint,
            modifier = Modifier.size(size)
        )
    }
}