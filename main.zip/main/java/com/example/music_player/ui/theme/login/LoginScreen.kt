package com.example.music_player.ui.theme.login

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.music_player.navigation.Screens
import com.example.music_player.R
import com.example.music_player.customDivider

@Composable
fun LoginScreen(navController: NavController,viewModel: LoginViewModel) {

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        // Back Button

        IconButton(
            onClick = { navController.navigateUp() },
            modifier = Modifier.align(Alignment.TopStart).padding(top=24.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White,
                modifier = Modifier.size(28.dp)

            )
        }

        // Column for Image & Text
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 50.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Image (Replace with your own image)
            Image(
                painter = painterResource(id = R.drawable.login_infographic),
                contentDescription = null,
                modifier = Modifier
                    .size(350.dp)  // Adjust size as needed
            )


            // Bold & Centered Text
            Text(
                text = "Let's you in",
                color = Color.White,
                fontSize = 45.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(24.dp))

            //Continue with google

            GoogleSignInButton(
                onClick = { viewModel.signInWithGoogle ( context= context , onSuccess={} ) },
                modifier = Modifier.padding(top = 20.dp)
            )

            Spacer(Modifier.height(12.dp))

            customDivider(text = "or")

            Spacer(Modifier.height(12.dp))

            // login with email button
            Button(
                onClick = {navController.navigate(Screens.loginWhithEmailScreen.route)},
                colors = ButtonDefaults.buttonColors(containerColor =  Color(0xFF1DB954)), // Spotify Green
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(24.dp)
            ) {
                Text(
                    text = "login with Password",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(Modifier.height(12.dp))

            //don't have account text
            Row(
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Text(
                    text = "Don't have an account? ",
                    color = Color.White,
                    fontSize = 14.sp
                )
                Text(
                    text = "Sign up",
                    color = Color(0xFF1DB954), // Spotify Green
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { /*navigate to sign up screen*/navController.navigate(Screens.createAccountScreen.route) }
                )
            }

        }
    }

}


@Composable
fun GoogleSignInButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth(0.9f) // Set width to 80% of screen
            .height(60.dp)
            .clip(RoundedCornerShape(14.dp)) // Rounded corners
            .background(Color(0x26FFFFFF)) // Semi-transparent greyish color
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_google), // Replace with actual Google logo drawable
                contentDescription = "Google Logo",
                modifier = Modifier
                    .size(32.dp)
                    .padding(end = 8.dp) // Space between logo and text
            )
            Spacer(Modifier.width(8.dp))

            Text(
                text = "Continue with Google",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}







