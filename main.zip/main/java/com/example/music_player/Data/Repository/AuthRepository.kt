package com.example.music_player.Data.Repository

import android.content.Context
import com.example.music_player.Data.Model.AuthResultWrapper
import com.example.music_player.Data.Model.user
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await

class AuthRepository(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
) {


    fun chechUserLogin(): Boolean{
        return auth.currentUser != null
    }

    // Get the current logged-in user
    fun getCurrentUser(): FirebaseUser? {
        return auth.currentUser
    }

    // Check if the current user's email is verified
    fun isEmailVerified(): Boolean {
        return auth.currentUser?.isEmailVerified ?: false
    }

    // Sign up with email and password
    suspend fun signUpWithEmail(email: String, password: String, name: String): AuthResultWrapper {
        return try {
            // Create user with email and password
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            result.user?.sendEmailVerification()?.await() // Send email verification

            // Save user data to Firestore
            val user = user(email, name)
            saveUserToFirestore(user)

            AuthResultWrapper.Success(result.user)
        } catch (e: FirebaseAuthUserCollisionException) {
            AuthResultWrapper.Failure("Email already in use")
        } catch (e: FirebaseNetworkException) {
            AuthResultWrapper.Failure("Network error. Please check your connection")
        } catch (e: Exception) {
            AuthResultWrapper.Failure("Sign-up failed: ${e.message}")
        }
    }


    // Login with email and password
    suspend fun loginWithEmail(email: String, password: String): AuthResultWrapper {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            if (result.user?.isEmailVerified == true) {
                AuthResultWrapper.Success(result.user)
            } else {
                auth.signOut()
                AuthResultWrapper.Failure("Please verify your email before signing in.")
            }
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            AuthResultWrapper.Failure("Invalid credentials")
        } catch (e: FirebaseNetworkException) {
            AuthResultWrapper.Failure("Network error. Please check your connection")
        } catch (e: Exception) {
            AuthResultWrapper.Failure("Login failed: ${e.message}")
        }
    }

    // Sign up with Google



    // Logout the user
    fun logout() {
        auth.signOut()
    }

    // Save user data to Firestore
    private suspend fun saveUserToFirestore(user: user) {
        val userDocumentRef = firestore.collection("Users").document(user.email)
        userDocumentRef.set(user).await()
    }
    // AuthRepository.kt
    suspend fun sendPasswordResetEmail(email: String): AuthResultWrapper {
        return try {
            // Just attempt to send the reset email
            auth.sendPasswordResetEmail(email).await()
            AuthResultWrapper.Success(null)
        } catch (e: FirebaseAuthInvalidUserException) {
            // This exception will only be thrown if the email is invalid format
            AuthResultWrapper.Failure("Invalid email address")
        } catch (e: FirebaseNetworkException) {
            AuthResultWrapper.Failure("Network error. Please check your connection")
        } catch (e: Exception) {
            AuthResultWrapper.Failure("Failed to send reset email: ${e.localizedMessage}")
        }
    }

}