package com.example.music_player.ui.theme.SignUp

import android.content.Context
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.music_player.Data.Model.AuthResultWrapper
import com.example.music_player.Data.Repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class SignUpViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {
    private val _name = mutableStateOf("")
    val name: State<String> = _name

    private val _email = mutableStateOf("")
    val email: State<String> = _email

    private val _password = mutableStateOf("")
    val password: State<String> = _password

    private val _uiState = mutableStateOf<SignUpUiState>(SignUpUiState.Nothing)
    val uiState: State<SignUpUiState> = _uiState

    sealed class SignUpUiState {
        object Nothing : SignUpUiState()
        object Loading : SignUpUiState()
        data class Error(val message: String) : SignUpUiState()
        data class Success(val message: String) : SignUpUiState()
    }

    fun onNameChange(newName: String) {
        _name.value = newName
    }

    fun onEmailChange(newEmail: String) {
        _email.value = newEmail
    }

    fun onPasswordChange(newPassword: String) {
        _password.value = newPassword
    }

    fun signUpUser(onSuccess: () -> Unit) {
        if (name.value.isBlank() || email.value.isBlank() || password.value.isBlank()) {
            _uiState.value = SignUpUiState.Error("All fields are required")
            return
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.value).matches()) {
            _uiState.value = SignUpUiState.Error("Please enter a valid email")
            return
        }

        val passwordValidationResult = validatePassword(password.value)
        if (!passwordValidationResult) {
            _uiState.value = SignUpUiState.Error("Please Choose a stronger password.Try a mix of letters,numbers and symbols")
            return
        }


        _uiState.value = SignUpUiState.Loading

        viewModelScope.launch {
            when (val result = authRepository.signUpWithEmail(
                email.value,
                password.value,
                name.value
            )) {
                is AuthResultWrapper.Success -> {
                    _uiState.value = SignUpUiState.Success("Account created successfully! Please verify your email.")
                    onSuccess()
                }
                is AuthResultWrapper.Failure -> {
                    val errorMessage = when {
                        result.errorMessage.contains("email already in use", ignoreCase = true) ->
                            "Email already in use"
                        result.errorMessage.contains("network", ignoreCase = true) ->
                            "Network error. Please check your connection"
                        else -> "Sign up failed: ${result.errorMessage}"
                    }
                    _uiState.value = SignUpUiState.Error(errorMessage)
                }
            }
        }
    }

    fun resetUiState() {
        _uiState.value = SignUpUiState.Nothing
        _email.value=""
        _password.value=""
        _name.value=""
    }
    fun signInWithGoogle(context: Context, onSuccess: () -> Unit) {


    }



    fun logout(navigateToLogin:()->Unit) {

        authRepository.logout()
        _uiState.value = SignUpUiState.Nothing

    }

    fun checkUserSession(onSuccess:()-> Unit) {
        _uiState.value = SignUpUiState.Loading
        val currentUser = authRepository.getCurrentUser()
        if (currentUser != null) {
            //_uiState.value = AuthResultWrapper.Success(currentUser)
            onSuccess()
        }
    }


    private fun validatePassword(password: String): Boolean {


        val hasLowercase = password.any { it.isLowerCase() }
        val hasDigit = password.any { it.isDigit() }
        val hasSpecialChar = password.any { !it.isLetterOrDigit() }
        if (password.length < 6||!hasLowercase||!hasDigit||!hasSpecialChar) {
            return false
        }
        return true
    }


}
