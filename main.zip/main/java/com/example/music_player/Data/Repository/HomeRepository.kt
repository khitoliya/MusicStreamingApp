package com.example.music_player.Data.Repository

import com.example.music_player.Data.Model.user
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await


class HomeRepository(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
){

     fun getCurrentUserEmail() : String{
        return auth.currentUser?.email ?: ""
    }

    suspend fun getUserDetails(email: String): user {
        return try {
            val document = firestore.collection("users").document(email).get().await()
            user(
                name = document.getString("name") ?: "User",
                email = document.getString("email") ?: "",

            )
        } catch (e: Exception) {
            throw HomeRepositoryException("Failed to fetch user details", e)
        }
    }


}

class HomeRepositoryException(message: String, cause: Throwable) : Exception(message, cause)



