package com.example.music_player.Data.Model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Serializable
@Parcelize
data class song(

    val id: String="",
    val title: String="",
    val artist: String= "",
    val thumbnailUrl: String ="", // Or String for URL
    val duration: String="", // ms
    val youtubeId: String="",
    val genre:String="",
    val mood:String="",
):Parcelable
