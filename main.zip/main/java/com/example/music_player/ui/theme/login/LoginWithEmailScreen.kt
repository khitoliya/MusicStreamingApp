package com.example.music_player.ui.theme.login

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.music_player.EmailTextField
import com.example.music_player.PasswordTextField
import com.example.music_player.R
import com.example.music_player.backButton
import com.example.music_player.customDivider
import com.example.music_player.greenButton
import com.example.music_player.navigation.Screens
import com.example.music_player.ui.theme.login.LoginViewModel
import com.example.music_player.ui.theme.login.LoginViewModel.LoginUiState


@Composable
fun loginWithEmailScreen(navController: NavController,viewModel: LoginViewModel){
    val email by viewModel.email
    val password by viewModel.password
    val uiState by viewModel.uiState
    val context = LocalContext.current





    // Handle success state
    LaunchedEffect(uiState) {
        if (uiState is LoginUiState.Success) {
            viewModel.resetUiState()
            navController.navigate(Screens.mainScreen.route) {
                popUpTo(Screens.loginWhithEmailScreen.route) { inclusive = true }
            }
        }
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = Color.Black)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Back Button
        backButton(onbackNavClick = {navController.navigateUp()})

        Spacer(Modifier.height(24.dp))

        // Image (Placeholder)
        Image(
            painter = painterResource(id = R.drawable.app_logo), // Replace with actual image
            contentDescription = "App Logo",
            modifier = Modifier
                .size(100.dp)
                .padding(top = 16.dp)
        )

        Spacer(Modifier.height(24.dp))

        // "Login to your account" Text
        Text(
            text = "Login to your account",
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 16.dp)
        )

        Spacer(Modifier.height(24.dp))
        //Email textBox
        EmailTextField(email,{viewModel.onEmailChange(it)})

        Spacer(Modifier.height(24.dp))
        //Password textBox
        PasswordTextField(password = password, onPasswordChange = { viewModel.onPasswordChange(it) })

        Spacer(Modifier.height(32.dp))

        // Login Button
        greenButton(
            "Login",
            onClick = { viewModel.loginUser(navigateOnSuccess = {navController.navigate(Screens.mainScreen.route) { popUpTo(0) } } )},
            isLoading = uiState is LoginUiState.Loading
        )

        //show error message
        if (uiState is LoginUiState.Error) {
            Spacer(Modifier.height(16.dp))
            Text(
                text = (uiState as LoginUiState.Error).message,
                color = Color.Red,
                modifier = Modifier.fillMaxWidth()
            )
        }


        Spacer(Modifier.height(28.dp))

        // Forgot Password (Clickable)
        Text(
            text = "Forgot Password?",
            color = Color(0xFF1DB954), // Spotify Green
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable { navController.navigate(Screens.forgotPasswordScreen.route) }
        )

        Spacer(Modifier.height(32.dp))

        //Divider
        customDivider("or continue with")

        Spacer(Modifier.height(12.dp))

        // google button
        Box(
            modifier = Modifier
                .size(60.dp) // Square shape
                .clip(RoundedCornerShape(12.dp)) // Rounded corners
                .background(Color.White.copy(alpha = 0.15f)) // Grey with 15% transparency
                .clickable { viewModel.signInWithGoogle(onSuccess = {navController.navigate(Screens.mainScreen.route) }, context = context)}, // Clickable effect
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_google), // Add your Google logo in drawable
                contentDescription = "Google Logo",
                modifier = Modifier.size(30.dp) // Adjust logo size
            )
        }

        Spacer(Modifier.height(16.dp))

        //don't have account text
        Row(
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text(
                text = "Don't have an account? ",
                color = Color.White,
                fontSize = 14.sp
            )
            Text(
                text = "Sign up",
                color = Color(0xFF1DB954), // Spotify Green
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { /*navigate to sign up screen*/ navController.navigate(Screens.createAccountScreen.route)}
            )
        }


    }


}



