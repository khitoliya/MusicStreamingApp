package com.example.music_player

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import coil.compose.AsyncImage
import com.example.music_player.navigation.Screens
import com.example.music_player.ui.theme.Player.MusicViewModel


@Composable
fun BackButton(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .shadow(6.dp, shape = RoundedCornerShape(12.dp)) // Light shadow added
            .background(color = Color.Black, shape = RoundedCornerShape(12.dp))
            .clickable { onClick() }, // Added click action here
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.KeyboardArrowLeft,
            contentDescription = null,
            tint = Color.White, // Optional: Change color if needed
        )
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmailTextField(email: String, onEmailChange: (String) -> Unit) {
    var isFocused by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = email,
        onValueChange = onEmailChange,
        placeholder = { Text("Email", color = Color.Gray) }, // Placeholder instead of label
        textStyle = TextStyle(color = Color.White), // Keep entered text white
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Email,
                contentDescription = "Email Icon",
                tint = if (email.isNotEmpty() || isFocused) Color.White else Color.Gray // White if text entered, else gray
            )
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .onFocusChanged { isFocused = it.isFocused }, // Track focus changes
        shape = RoundedCornerShape(12.dp), // Rounded corners
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF1DB954).copy(alpha = 0.2f), // Green tint when focused
            unfocusedContainerColor = Color.Gray.copy(alpha = 0.15f), // Light gray background
            focusedIndicatorColor = Color(0xFF1DB954), // Green border when focused
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Color(0xFF1DB954), // Green cursor
            focusedLeadingIconColor = Color.White, // Keep icon white when focused
            unfocusedLeadingIconColor = if (email.isNotEmpty()) Color.White else Color.Gray // White if text entered, else gray
        )
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordTextField(password: String, onPasswordChange: (String) -> Unit) {
    var isFocused by remember { mutableStateOf(false) }
    var passwordVisible by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = password,
        onValueChange = onPasswordChange,
        placeholder = { Text("Password", color = Color.Gray) }, // Placeholder instead of label
        textStyle = TextStyle(color = Color.White), // Keep entered text white
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Password Icon",
                tint = if (password.isNotEmpty() || isFocused) Color.White else Color.Gray // White if text entered, else gray
            )
        },
        trailingIcon = {
            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                Icon(
                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    contentDescription = "Toggle Password Visibility",
                    tint = if (password.isNotEmpty() || isFocused) Color.White else Color.Gray // White if text entered, else gray
                )
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .onFocusChanged { isFocused = it.isFocused }, // Track focus changes
        shape = RoundedCornerShape(12.dp), // Rounded corners
        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF1DB954).copy(alpha = 0.2f), // Green tint when focused
            unfocusedContainerColor = Color.Gray.copy(alpha = 0.15f), // Light gray background
            focusedIndicatorColor = Color(0xFF1DB954), // Green border when focused
            unfocusedIndicatorColor = Color.Transparent, // No border when not focused
            cursorColor = Color(0xFF1DB954), // Green cursor
            focusedLeadingIconColor = Color.White, // Keep icon white when focused
            unfocusedLeadingIconColor = if (password.isNotEmpty()) Color.White else Color.Gray, // White if text entered, else gray
            focusedTrailingIconColor = Color.White, // Eye icon color when focused
            unfocusedTrailingIconColor = if (password.isNotEmpty()) Color.White else Color.Gray // White if text entered, else gray
        )
    )
}

@Composable
fun backButton(onbackNavClick :()-> Unit){
    // Back Button
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top=24.dp),
        contentAlignment = Alignment.TopStart
    ) {
        IconButton(onClick = onbackNavClick ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White,
                modifier=Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun customDivider(text: String){
    //Divider
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Modifier.weight(1f)
        Color.Gray.copy(alpha = 0.5f)
        HorizontalDivider(modifier = Modifier.weight(1f),1.dp, Color.Gray.copy(alpha = 0.5f))
        Text(
            text = text,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
        HorizontalDivider(modifier = Modifier.weight(1f),1.dp, Color.Gray.copy(alpha = 0.5f))
    }
}

@Composable
fun greenButton(text: String,onClick: () -> Unit, isLoading: Boolean=false){

    Button(
        onClick = onClick ,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DB954)), // Spotify Green
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .padding(horizontal = 20.dp),
        shape = RoundedCornerShape(10.dp) // Rounded corners
    ) {
        if(isLoading){
            CircularProgressIndicator(color = Color.White)
        }
        else{
            Text(text, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

    }
}

@Composable
fun OtpTextBox(
    otp: MutableState<String>,
    otpLength: Int = 4,
    modifier: Modifier = Modifier
) {
    val focusRequesters = remember { List(otpLength) { FocusRequester() } }
    val otpDigits = remember { mutableStateOf(List(otpLength) { "" }) }
    val greenColor = Color(0xFF1DB954)
    val unfocusedColor = Color.Gray

    // Request focus on the first field initially
    LaunchedEffect(Unit) {
        focusRequesters[0].requestFocus()
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        (0 until otpLength).forEach { index ->
            val isFocused = remember { mutableStateOf(false) }

            BasicTextField(
                value = otpDigits.value[index],
                onValueChange = { newValue ->
                    if (newValue.isEmpty() || newValue.all { it.isDigit() }) {
                        // Update current digit
                        val updatedDigits = otpDigits.value.toMutableList()
                        updatedDigits[index] = newValue.take(1)
                        otpDigits.value = updatedDigits

                        // Update combined OTP
                        otp.value = otpDigits.value.joinToString("")

                        // Move focus forward on input
                        if (newValue.isNotEmpty() && index < otpLength - 1) {
                            focusRequesters[index + 1].requestFocus()
                        }
                        // Move focus backward on backspace
                        else if (newValue.isEmpty() && index > 0) {
                            focusRequesters[index - 1].requestFocus()
                        }
                    }
                },
                modifier = Modifier
                    .width(60.dp)
                    .height(60.dp)
                    .focusRequester(focusRequesters[index])
                    .onFocusChanged { isFocused.value = it.isFocused }
                    .background(
                        color = Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isFocused.value) greenColor else unfocusedColor,
                        shape = RoundedCornerShape(12.dp)
                    ),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = if (index == otpLength - 1) ImeAction.Done else ImeAction.Next
                ),
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(
                    color = Color.White, // Explicit white text
                    fontSize = 22.sp,
                    textAlign = TextAlign.Center,
                    background = Color.Transparent
                ),
                cursorBrush = SolidColor(greenColor),
                decorationBox = { innerTextField ->
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        innerTextField()
                    }
                }
            )
        }
    }
}


@Composable
fun BottomNavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) Color.Green else Color.White,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = if (selected) Color.Green else Color.White,
            fontSize = 12.sp
        )
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun BottomBar(bottomNavController: NavController, musicViewModel: MusicViewModel,mainNavController: NavController) {
    val items = listOf(Screens.homeScreen, Screens.explore, Screens.library, Screens.Profile)
    val isMiniPlayerOpen by musicViewModel.MiniPlayerOpen.collectAsState()
    val currDuration by musicViewModel.currDuration.collectAsState()
    val maxDuration by musicViewModel.maxDuration.collectAsState()


    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .background(Color.Black),
        color = Color(0xFF1E1E1E)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Seek bar at the very top of the Surface
            if (isMiniPlayerOpen) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .background(Color.Transparent) //Gray.copy(alpha = 0.3f)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(
                                fraction = if (maxDuration > 0f) currDuration / maxDuration else 0f
                            )
                            .height(2.dp)
                            .background(Color.Gray)
                    )
                }
            }

            Column (modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(PaddingValues(start = 8.dp,end=8.dp, bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()+8.dp,top= if(isMiniPlayerOpen) 4.dp else 8.dp))
            ){
                if (isMiniPlayerOpen) {

                    MiniPlayer(
                        musicViewModel = musicViewModel,
                        onClick = {
                            mainNavController.navigate("player")
                            musicViewModel.setMiniPlayerOpen(false)
                        }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
                ) {
                items.forEach { section ->
                    val navBackStackEntry by bottomNavController.currentBackStackEntryAsState()
                    val selected = section.route == navBackStackEntry?.destination?.route
                    Log.d("Value of Selected", (selected).toString())

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { bottomNavController.navigate(section.route) }
                    ) {
                        Icon(
                            imageVector = if (selected) {section.filledIcon ?:Icons.Default.Error}   else {section.outlinedIcon ?:Icons.Default.Error},
                            contentDescription = section.route,
                            tint = if (selected) Color.Green else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = section.route.replaceFirstChar { it.uppercase() },
                            color = if (selected) Color.Green else Color.White,
                            fontSize = 12.sp
                        )
                    }
                }
            }



        }
    }
}}

@androidx.annotation.OptIn(UnstableApi::class)
@OptIn(UnstableApi::class)
@Composable
fun MiniPlayer(
    musicViewModel: MusicViewModel,
    onClick: () -> Unit,
) {
    val currentSong by musicViewModel.currentSong.collectAsState()
    val isPlaying by musicViewModel.isPlaying.collectAsState()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .clickable(onClick = onClick),
        color = Color(0xFF1E1E1E)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail
            AsyncImage(
                model = currentSong?.thumbnailUrl,
                contentDescription = "Song thumbnail",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(8.dp)),
                placeholder = painterResource(R.drawable.placeholder),
                error = painterResource(R.drawable.placeholder)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Song info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = currentSong?.title ?: "Unknown Song",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = currentSong?.artist ?: "Unknown Artist",
                    color = Color.Gray,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Player controls
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Play/Pause button
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = { musicViewModel.playPause() },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color.Black,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Next button
                IconButton(
                    onClick = { musicViewModel.next() },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Next",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

data class GridItem(
    val subheading: String,
    val icon: Any, // Can be ImageVector or painter resource ID
    val gradientColors: List<Color>
)

@Composable
fun GridWithHeader(
    heading: String,
    items: List<GridItem>,
    onItemClick: (String) -> Unit,
    onSeeMoreClick: () -> Unit,
    modifier: Modifier = Modifier,
    tileSpacing: Dp = 16.dp,
    tileHeight: Dp = 80.dp
) {
    Column(modifier = modifier) {
        // Header row with title and "See More" button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = heading,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = Color.White
                ),
                modifier = Modifier.padding(start = 16.dp)
            )

            if (items.size > 6) {
                TextButton(
                    onClick = onSeeMoreClick,
                    modifier = Modifier.padding(end = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.2f), contentColor = Color.White)
                ) {
                    Text("See More")
                }
            } else {
                Spacer(modifier = Modifier.width(80.dp)) // For balance when "See More" isn't shown
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grid layout - 3 rows x 2 columns
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(tileSpacing)
        ) {
            // Process items in chunks of 2 for each row
            items.chunked(2).take(3).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(tileSpacing)
                ) {
                    rowItems.forEachIndexed { index, item ->
                        GridTile(
                            item = item,
                            modifier = Modifier
                                .weight(1f)
                                .height(tileHeight)
                                .clickable { onItemClick(item.subheading) }
                        )
                    }

                    // Add empty space if row has less than 2 items
                    if (rowItems.size < 2) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun GridTile(
    item: GridItem,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(
                    colors = item.gradientColors,
                    startY = 0f,
                    endY = Float.POSITIVE_INFINITY
                )
            )
            .padding(16.dp),
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxSize()) {
            // Handle different icon types


            Text(
                text = item.subheading,
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = Color.White,
                    fontSize = 16.sp
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            when (item.icon) {
                is ImageVector -> {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = null,
                        modifier = Modifier.size(32.dp),
                        tint = Color.White
                    )
                }
                is Int -> {
                    Icon(
                        painter = painterResource(id = item.icon),
                        contentDescription = null,
                        modifier = Modifier.size(32.dp),
                        tint = Color.White
                    )
                }
            }

        }
    }
}
