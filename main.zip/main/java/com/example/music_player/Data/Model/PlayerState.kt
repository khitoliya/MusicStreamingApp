package com.example.music_player.Data.Model

data class PlayerState(
    val currentSong: song? = null,
    val isPlaying: Boolean = false,
    val currentPosition: Long = 0L,
    val isMinimized: Boolean = true, // Start minimized
    val queue: List<song> = emptyList(),
    val currentQueueIndex: Int = 0,
    val isShuffleOn: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF
)

enum class RepeatMode { OFF, ONE, ALL }
