package com.example.music_player.ui.theme.login

import android.content.Context
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.music_player.Data.Model.AuthResultWrapper
import com.example.music_player.Data.Repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    sealed class LoginUiState {
        object Nothing : LoginUiState()
        object Loading : LoginUiState()
        data class Error(val message: String) : LoginUiState()
        data class Success(val message: String) : LoginUiState()
    }

    private val _isLoggedIn = mutableStateOf(false)
    val isLoggedIn: State<Boolean> = _isLoggedIn
    init {
        _isLoggedIn.value= authRepository.chechUserLogin()
    }


    private val _email = mutableStateOf("")
    val email: State<String> = _email

    private val _password = mutableStateOf("")
    val password: State<String> = _password

    private val _uiState = mutableStateOf<LoginUiState>(LoginUiState.Nothing)
    val uiState: State<LoginUiState> = _uiState

    fun onEmailChange(newEmail: String) {
        _email.value = newEmail
    }

    fun onPasswordChange(newPassword: String) {
        _password.value = newPassword
    }

    fun loginUser(navigateOnSuccess: () -> Unit) {
        if (email.value.isBlank() || password.value.isBlank()) {
            _uiState.value = LoginUiState.Error("Email and password cannot be empty")
            return
        }

        _uiState.value = LoginUiState.Loading

        viewModelScope.launch {
            when (val result = authRepository.loginWithEmail(email.value, password.value)) {
                is AuthResultWrapper.Success -> {
                    _uiState.value = LoginUiState.Success("Login successful")
                    navigateOnSuccess()
                }
                is AuthResultWrapper.Failure -> {
                    val errorMessage = when {
                        result.errorMessage.contains("invalid credential", ignoreCase = true) -> "Invalid credentials"
                        result.errorMessage.contains("network error", ignoreCase = true) -> "Network error. Please check your connection"
                        result.errorMessage.contains("verify",ignoreCase = true) -> "Please verify your email before signing in."
                        else -> "Unexpected error occurred"
                    }
                    _uiState.value = LoginUiState.Error(errorMessage)
                }
            }
        }
    }
    fun signInWithGoogle(context: Context, onSuccess: () -> Unit) {


    }

    fun resetUiState() {
        _uiState.value = LoginUiState.Nothing
    }
    fun logout(){
        authRepository.logout()
        _uiState.value= LoginUiState.Nothing
        _email.value=""
        _password.value=""
        _isLoggedIn.value=false
    }
}