package com.example.music_player.ui.theme.Player
import android.Manifest.permission.POST_NOTIFICATIONS
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.support.v4.media.session.MediaSessionCompat
import android.util.Log
import androidx.annotation.OptIn
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import com.example.music_player.CHANNEL_ID
import com.example.music_player.Data.Model.song
import com.example.music_player.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

const val PREV ="prev"
const val NEXT="next"
const val PLAY_PAUSE = "play_pause"

@UnstableApi
class MediaPlayerService : Service(){
    enum class RepeatMode {
        OFF,       // No repeating - stop after current song
        ALL,       // Normal playback - go to next song when current ends
        ONE        // Play each song twice before moving to next
    }

    val binder =MusicBinder()
    internal lateinit var mediaPlayer: ExoPlayer
    private val maxDuration = MutableStateFlow(0f)
    private val currDuration = MutableStateFlow(0f)
    val scope= CoroutineScope(Dispatchers.Main + Job())
    private var job: Job? = null
    private var currentSong = MutableStateFlow<song>(song())
    private var musicList = mutableListOf<song>()
    private val isPlaying= MutableStateFlow<Boolean>(false)
    private val isPlayerReady = MutableStateFlow(false)
    private lateinit var mediaSession: MediaSessionCompat
    private lateinit var cache: SimpleCache
    private lateinit var cacheDataSourceFactory: DataSource.Factory
    private var originalPlaylist: List<song> = emptyList()
    private val isShuffleOn = MutableStateFlow(false)

    private val repeatMode = MutableStateFlow(RepeatMode.ALL) // Default to ALL
    private var playCount = 1 // Tracks how many times current song has played

    inner class MusicBinder:Binder(){
        fun getService()=this@MediaPlayerService
        fun setMusicList(list: List<song>){
            Log.d("MusicList","before Update ${musicList}")
            this@MediaPlayerService.originalPlaylist =list.toMutableList()
            this@MediaPlayerService.musicList=if (isShuffleOn.value) list.toMutableList().apply { shuffle() } else list.toMutableList()
            Log.d("MusicList","After Update ${musicList}")

        }
        fun currentDuration()= this@MediaPlayerService.currDuration
        fun maxDuration()=this@MediaPlayerService.maxDuration
        fun isPlaying()=this@MediaPlayerService.isPlaying
        fun getCurrSong()=this@MediaPlayerService.currentSong
        fun isPlayerReady() = this@MediaPlayerService.isPlayerReady
        fun isShuffleOn() = this@MediaPlayerService.isShuffleOn
        fun getRepeatMode() = this@MediaPlayerService.repeatMode

    }
    fun toggleRepeatMode() {
        repeatMode.value = when (repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        playCount = 1 // Reset play count when changing mode
    }

    fun toggleShuffle() {
        if (!isShuffleOn.value) {
            // Turn shuffle on - save original and shuffle
            originalPlaylist = musicList.toList()
            musicList = musicList.toMutableList().apply {
                // Keep current song as first item
                remove(currentSong.value)
                shuffle()
                add(0, currentSong.value)
            }
        } else {
            // Turn shuffle off - restore original playlist
            musicList = originalPlaylist.toMutableList()

            // If current song not found (shouldn't happen), start from beginning
        }
        isShuffleOn.value = !isShuffleOn.value
        sendNotification(currentSong.value)
    }

    @OptIn(UnstableApi::class)
    fun initializePlayer() {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                1000, // Min buffer (1 second to start)
                300000, // Max buffer (30 seconds, adjust based on song length)
                500,  // Buffer for playback (0.5 seconds)
                500   // Buffer after rebuffer (0.5 seconds)
            )
            .setTargetBufferBytes(-1) // Load entire song into cache if possible
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        mediaPlayer = ExoPlayer.Builder(applicationContext)
            .setLoadControl(loadControl)
            .build()

        mediaPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isPlayerReady.update { state == Player.STATE_READY || state == Player.STATE_ENDED }
                if (state == Player.STATE_ENDED) {
                    // Clear cache when song ends naturally
                    clearCacheForSong(currentSong.value)
                    handlePlaybackEnded()
                }
                if (state == Player.STATE_READY && mediaPlayer.isPlaying) {
                    updateDuration()
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                this@MediaPlayerService.isPlaying.update { isPlaying }
                sendNotification(currentSong.value)
            }
        })
    }

    private fun handlePlaybackEnded() {
        when (repeatMode.value) {
            RepeatMode.ONE -> {
                if (playCount < 2) {
                    // Play same song again
                    playCount++
                    mediaPlayer.seekTo(0)
                    mediaPlayer.play()
                } else {
                    // Move to next song after playing twice
                    playCount = 1
                    next()
                }
            }
            RepeatMode.ALL -> {
                // Normal behavior - go to next song
                next()
            }
            RepeatMode.OFF -> {
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        setupCaching()
        initializePlayer()
        mediaSession = MediaSessionCompat(this, "music")
        startForeground(1, createNotification())
        scope.launch {
            Log.d("ScopeDebug", "Scope is active in onCreate")
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
        mediaSession.release() // Clean up media session
        cache.release()
        job?.cancel()
    }


    override fun onBind(p0: Intent?): IBinder? {
        return binder
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let{
            when(intent.action){
                PREV->{
                    prev()
                }
                NEXT->{
                    next()
                }
                PLAY_PAUSE ->{
                    playPause()
                }
                else -> {
                    Log.d("Rohit","inside else")
                    val newMusicList = intent.getParcelableArrayListExtra<song>("MUSIC_LIST")
                    if (newMusicList != null) {
                        musicList = newMusicList // Update the service's music list
                        if (musicList.isNotEmpty()) {
                            currentSong.value = musicList[0]
                             Play(song = currentSong.value) // Set first song as current
                             // Start playing
                        }
                    }

                }
            }
        }
        return START_STICKY
    }

    fun setupCaching() {
        val cacheDir = File(applicationContext.cacheDir, "media")
        // Smaller cache size (e.g., 50MB) since we clear it per song
        cache = SimpleCache(cacheDir, androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor(200 * 1024 * 1024))
        val defaultDataSourceFactory = DefaultDataSource.Factory(applicationContext)
        cacheDataSourceFactory = CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(defaultDataSourceFactory)
            .setCacheReadDataSourceFactory(defaultDataSourceFactory) // Ensure cache is read from
            .setFlags(0)
    }
    fun clearCacheForSong(song: song) {
        cache.removeResource(song.youtubeId) // Use youtubeId as cache key
    }
    fun playWithCaching(song: song) {
        playCount = 1
        Log.d("CacheDebug", "Attempting to play song: ${song.title}")
        currentSong.value=song
        stopAndReset()
        currentSong.update { song }
        val uri = "https://drive.google.com/uc?export=download&id=${song.youtubeId}"
        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setMediaId(song.youtubeId) // Use youtubeId as a stable cache key
            .build()
        val mediaSource = ProgressiveMediaSource.Factory(cacheDataSourceFactory)
            .createMediaSource(mediaItem)
        clearCacheForSong(currentSong.value)
        mediaPlayer.setMediaSource(mediaSource)
        mediaPlayer.prepare()
        mediaPlayer.play()
        Log.d("CacheDebug", "Player state after play(): ${mediaPlayer.playbackState}, isPlaying: ${mediaPlayer.isPlaying}")

        // Log cache status
        scope.launch {
            Log.d("CacheDebug", "Coroutine started for song: ${song.title}")
            while (mediaPlayer.playbackState == Player.STATE_BUFFERING ||
                mediaPlayer.playbackState == Player.STATE_READY ||
                mediaPlayer.isPlaying) {
                val bufferedPosition = mediaPlayer.bufferedPosition
                val duration = mediaPlayer.duration
                val state = mediaPlayer.playbackState
                val isPlaying = mediaPlayer.isPlaying
                Log.d("CacheDebug", "Buffered: $bufferedPosition / $duration (State: $state, Playing: $isPlaying)")
                if (bufferedPosition >= duration && duration > 0) {
                    Log.d("CacheDebug", "Song fully cached!")
                    break
                }
                delay(1000)
            }
            Log.d("CacheDebug", "Coroutine ended for song: ${song.title}")
        }
        sendNotification(song)
    }
    fun stopAndReset() {
        mediaPlayer.stop()
        mediaPlayer.clearMediaItems()
        Log.d("CacheDebug", "Player stopped and reset")
    }


    fun prev() {
        val index = musicList.indexOf(currentSong.value)
        val prevIndex = if (index - 1 < 0) musicList.size - 1 else index - 1
        val prevItem = musicList[prevIndex]
        clearCacheForSong(currentSong.value)
        playWithCaching(prevItem)
    }
    fun next() {
        Log.d("MusicList","list  is ${musicList}")
        val index = musicList.indexOf(currentSong.value)
        Log.d("MusicList","currentSong is ${currentSong.value.title} at index: ${index}")
        val nextIndex = (index + 1) % musicList.size
        val nextItem = musicList[nextIndex]
        Log.d("MusicList","NextSong is ${nextItem.title} at index :$nextIndex")
        clearCacheForSong(currentSong.value)
        Log.d("MusicList","Playing next song")
        playWithCaching(nextItem)
    }
    private fun Play(song: song) {
        playWithCaching(song)
    }
    fun updateDuration() {
        job?.cancel() // Cancel any existing job
        job = scope.launch {
            while (mediaPlayer.isPlaying || mediaPlayer.playbackState == Player.STATE_READY) {
                maxDuration.update { mediaPlayer.duration.toFloat().coerceAtLeast(0f) }
                currDuration.update { mediaPlayer.currentPosition.toFloat().coerceAtLeast(0f) }
                sendNotification(currentSong.value)
                delay(1000) // Update every second
            }
        }
    }
    fun playPause(){
        if(mediaPlayer.isPlaying){
            mediaPlayer.pause()
        }else{
            if (mediaPlayer.currentPosition >= mediaPlayer.duration - 100 && mediaPlayer.duration > 0) {
                // If song has ended (within last 100ms), restart from beginning
                mediaPlayer.seekTo(0)
            }
            mediaPlayer.play()
        }
        sendNotification(currentSong.value)
    }
    fun seekTo(position: Long){
        val bufferedPosition = mediaPlayer.bufferedPosition
        Log.d("SeekDebug", "Seeking to $position, Buffered: $bufferedPosition")
        if (position <= bufferedPosition) {
            Log.d("SeekDebug", "Seeking within cached portion")
        } else {
            Log.d("SeekDebug", "Seeking beyond cached portion - may buffer")
        }
        mediaPlayer.seekTo(position)
    }


    private fun createNotification(): Notification {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Media Playback",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Music Player")
            .setContentText("Playing your music...")
            .setSmallIcon(R.drawable.app_logo)
            .build()
    }
    private fun sendNotification(song: song){
        isPlaying.update { mediaPlayer.isPlaying }
        val playPauseIcon = when {
            !isPlayerReady.value -> R.drawable.circular_progress_indicator// Loading icon
            mediaPlayer.isPlaying -> android.R.drawable.ic_media_pause
            else -> android.R.drawable.ic_media_play
        }
        val bitmap = try {
                song.thumbnailUrl.let { url ->
                    val connection = URL(url).openConnection() as HttpURLConnection
                    connection.doInput = true
                    connection.connectTimeout = 500
                    connection.readTimeout = 500
                    connection.connect()
                    val input = connection.inputStream
                    BitmapFactory.decodeStream(input)
                }
            } catch (e: Exception) {
                Log.e("Rohit","error while loading image")
                BitmapFactory.decodeResource(resources,R.drawable.ic_launcher_background)
            }



        val style= androidx.media.app.NotificationCompat.MediaStyle().setShowActionsInCompactView(0,1,2).setMediaSession(mediaSession.sessionToken)
        val notification= NotificationCompat.Builder(this, CHANNEL_ID)
            .setStyle(style)
            .setContentTitle(song.title)
            .setContentText(song.artist)
            .addAction(android.R.drawable.ic_media_previous,"prev",createPrevPendingIntent())
            .addAction(playPauseIcon,"play_pause",createPlayPausePendingIntent()) //use media player to decide wether play icon will come or pause icon
            .addAction(android.R.drawable.ic_media_next,"next",createNextPendingIntent())
            .setSmallIcon(R.drawable.app_logo)//show app logo
            .setLargeIcon(bitmap) //show song art
            .build()

        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.TIRAMISU){
            if(ContextCompat.checkSelfPermission(this,POST_NOTIFICATIONS)== PackageManager.PERMISSION_GRANTED){
                startForeground(1,notification)
            }else{
                startForeground(1,notification)
            }
        }

        // Load thumbnail async and update notification


    }

    fun createPrevPendingIntent(): PendingIntent{
        val intent= Intent(this, MediaPlayerService::class.java).apply{action=PREV}
        return PendingIntent.getService(this,0,intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    }
    fun createPlayPausePendingIntent(): PendingIntent{
        val intent= Intent(this, MediaPlayerService::class.java).apply{action=PLAY_PAUSE}
        return PendingIntent.getService(this,0,intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    }
    fun createNextPendingIntent(): PendingIntent{
        val intent= Intent(this, MediaPlayerService::class.java).apply{action=NEXT}
        return PendingIntent.getService(this,0,intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    }

}