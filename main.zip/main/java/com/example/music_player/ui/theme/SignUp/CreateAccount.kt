package com.example.music_player.ui.theme.SignUp

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.music_player.R
import androidx. compose. runtime. getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import com.example.music_player.EmailTextField
import com.example.music_player.PasswordTextField
import com.example.music_player.backButton
import com.example.music_player.customDivider
import com.example.music_player.greenButton
import com.example.music_player.navigation.Screens
import com.example.music_player.ui.theme.SignUp.SignUpViewModel.SignUpUiState



@Composable
fun createAccount(navController: NavController,viewModel: SignUpViewModel){
    val email by viewModel.email
    val password by viewModel.password
    val name by viewModel.name
    val context = LocalContext.current
    val uiState by viewModel.uiState

    // For showing the success dialog
    var showSuccessDialog by remember { mutableStateOf(false) }

    // Observe UI state changes
    LaunchedEffect(uiState) {
        if (uiState is SignUpUiState.Success) {
            showSuccessDialog = true
            viewModel.resetUiState()
        }
    }

    // Success Dialog
    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false;navController.navigate(Screens.loginScreen.route) { popUpTo(Screens.createAccountScreen.route) { inclusive = true } }},
            title = { Text("Verification Email Sent") },
            text = { Text("Account created successfully! Please verify your email.") },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        navController.navigate(Screens.loginScreen.route) { popUpTo(Screens.createAccountScreen.route) { inclusive = true } }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DB954))
                ){
                        Text("OK")
                    }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = Color.Black)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Back Button
        backButton(onbackNavClick = {navController.navigateUp()})

        Spacer(Modifier.height(24.dp))

        // Image (Placeholder)
        Image(
            painter = painterResource(id = R.drawable.app_logo), // Replace with actual image
            contentDescription = "App Logo",
            modifier = Modifier
                .size(100.dp)
                .padding(top = 16.dp)
        )

        Spacer(Modifier.height(24.dp))

        // "Login to your account" Text
        Text(
            text = "Create Your Account",
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 16.dp)
        )

        Spacer(Modifier.height(24.dp))

        //name textbox
        NameTextField(name,{viewModel.onNameChange((it))})

        Spacer(Modifier.height(24.dp))
        //Email textBox
        EmailTextField(email,{viewModel.onEmailChange(it)})

        Spacer(Modifier.height(24.dp))
        //Password textBox
        PasswordTextField(password = password, onPasswordChange = { viewModel.onPasswordChange(it) })

        Spacer(Modifier.height(32.dp))

        // Login Button
        greenButton(
            "Sign Up",
            onClick = {viewModel.signUpUser(onSuccess =  {/*show dialog to tell user to verify his email */ }  )},
            isLoading = uiState is SignUpUiState.Loading
        )

        if (uiState is SignUpUiState.Error) {
            Spacer(Modifier.height(16.dp))
            Text(
                text = (uiState as SignUpUiState.Error).message,
                color = Color.Red,
                modifier = Modifier.fillMaxWidth()
            )
        }


        Spacer(Modifier.height(24.dp))


        //Divider
        customDivider("or continue with")

        Spacer(Modifier.height(12.dp))

        // google button
        Box(
            modifier = Modifier
                .size(60.dp) // Square shape
                .clip(RoundedCornerShape(12.dp)) // Rounded corners
                .background(Color.White.copy(alpha = 0.15f)) // Grey with 15% transparency
                .clickable { viewModel.signInWithGoogle(context, onSuccess = {})}, // Clickable effect
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_google), // Add your Google logo in drawable
                contentDescription = "Google Logo",
                modifier = Modifier.size(30.dp) // Adjust logo size
            )
        }

        Spacer(Modifier.height(16.dp))

        //don't have account text
        Row(
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text(
                text = "Already have an account? ",
                color = Color.White,
                fontSize = 14.sp
            )
            Text(
                text = "Sign in",
                color = Color(0xFF1DB954), // Spotify Green
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { /*navigate to login screen*/ navController.navigate(Screens.loginScreen.route) }
            )
        }


    }


}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NameTextField(email: String, onNameChange: (String) -> Unit) {
    var isFocused by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = email,
        onValueChange = onNameChange,
        placeholder = { Text("Name", color = Color.Gray) }, // Placeholder instead of label
        textStyle = TextStyle(color = Color.White), // Keep entered text white
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = "Email Icon",
                tint = if (email.isNotEmpty() || isFocused) Color.White else Color.Gray // White if text entered, else gray
            )
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .onFocusChanged { isFocused = it.isFocused }, // Track focus changes
        shape = RoundedCornerShape(12.dp), // Rounded corners
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF1DB954).copy(alpha = 0.2f), // Green tint when focused
            unfocusedContainerColor = Color.Gray.copy(alpha = 0.15f), // Light gray background
            focusedIndicatorColor = Color(0xFF1DB954), // Green border when focused
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Color(0xFF1DB954), // Green cursor
            focusedLeadingIconColor = Color.White, // Keep icon white when focused
            unfocusedLeadingIconColor = if (email.isNotEmpty()) Color.White else Color.Gray // White if text entered, else gray
        )
    )
}


