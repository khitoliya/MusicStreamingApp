package com.example.music_player.navigation


import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.music_player.Data.Model.song
import com.example.music_player.MainAppScaffold
import com.example.music_player.ui.theme.Player.MusicViewModel
import com.example.music_player.ui.theme.Player.PlayerScreen
import com.example.music_player.ui.theme.SignUp.SignUpViewModel
import com.example.music_player.ui.theme.SignUp.createAccount
import com.example.music_player.ui.theme.login.LoginScreen
import com.example.music_player.ui.theme.login.LoginViewModel
import com.example.music_player.ui.theme.login.loginWithEmailScreen
import com.example.music_player.ui.theme.otpVerification.forgotpasswordScreen


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun NavGraph(navController: NavHostController){
    val signUpViewModel: SignUpViewModel = hiltViewModel()
    val loginviewModel: LoginViewModel = hiltViewModel()
    val musicViewModel: MusicViewModel=hiltViewModel()
    val isLogin by loginviewModel.isLoggedIn
    NavHost(
        navController = navController,
        startDestination = if(isLogin)Screens.mainScreen.route else Screens.loginScreen.route,
        enterTransition = {
            slideIntoContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.Left,
                animationSpec = tween(300)
            )+ fadeIn(animationSpec = tween(300))
        },
        exitTransition = {
            slideOutOfContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.Left,
                animationSpec = tween(300)
            )+ fadeOut(animationSpec = tween(300))
        },
        popEnterTransition = {
            slideIntoContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.Right,
                animationSpec = tween(300)
            )+ fadeIn(animationSpec = tween(300))
        },
        popExitTransition = {
            slideOutOfContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.Right,
                animationSpec = tween(300)
            )+ fadeOut(animationSpec = tween(300))
        }
    ){
        composable(Screens.loginScreen.route){
            LoginScreen(navController= navController, loginviewModel)
        }
        composable ( Screens.loginWhithEmailScreen.route ){
            loginWithEmailScreen(navController,loginviewModel)
        }
        composable(Screens.mainScreen.route) {
            MainAppScaffold(mainNavController = navController,loginViewModel=loginviewModel, musicViewModel = musicViewModel)
        }
        composable (Screens.createAccountScreen.route){
            createAccount(navController,signUpViewModel)
        }
        composable(Screens.forgotPasswordScreen.route){
            forgotpasswordScreen(navController = navController)

        }
        composable("player") { // Simplified route, no arguments
            PlayerScreen(mainNavController = navController, viewModel = musicViewModel)
        }



    }
    



}