package com.example.music_player.Data.Model

data class playlist(
    val id:String,
    val name:String,
    val userId:String,
    val songId:String,
    val is_public:Boolean
)